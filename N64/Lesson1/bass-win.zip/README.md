#### Building
Requires make and coreutils (msys/cygwin on windows)
```
git clone https://github.com/ARM9/bass.git && cd bass/bass && make
```

