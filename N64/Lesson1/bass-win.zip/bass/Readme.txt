The arch folder.
The bass compiler uses this folder during compilation to determine the platforms and instructions that are supported. It's not very friendly to read but it may be helpful at some point to confirm if an instruction is available in the included release.

bass assembler 
The bass assembler source is available on github, although I'm not sure the license used. It supports most N64 features. It was first created by byuu to support the SNES while he was also creating the SNES cycle accurate emulator bsnes later renamed and expanded under the name higan. The original bass was forked by ARM9 and modified to support many additional platforms. The included exe is compiled for Windows and slightly modifed to avoid an unneeded warning. See the GPL folder for version of source code compiled for this release.

A checksum generator for N64 ROM's s included in the Bin Folder it's definitely GPL so see the GPL folder for source code. I modified the source to add a -v Verbose option. Now the default is to output only the Version + License string and success or failure messages. Originally it would output the existing chksum values then the new values. Adding -v will return to the original behavior. Also created a quick batch file to "make" the exe.

A run.cmd batch file to start Mame in either normal or debug mode. Has some interesting points because it will run every N64 extension file in the current folder. The expectation is that users will create a new folder for the source files etc of each new lesson.

The bass compiler includes some html help but it discusses the use of the compiler in fairly technical terms and goes deeper in to the compilers architecture than some folks would like. I would encourage it to be at least browsed at some point. 

The GPL folder contains source code, some that was released under the original GPL. The bass source isn't clearly licensed so I'm sharing my changes here anyway. 